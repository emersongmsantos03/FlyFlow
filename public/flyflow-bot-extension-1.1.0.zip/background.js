const allowedSite = 'https://flyflow-a97ab.web.app/'

const deliverToWhatsApp = async (tabId, command) => {
  const startedAt = Date.now()
  let lastError = ''
  while (Date.now() - startedAt < 55_000) {
    try {
      const tab = await chrome.tabs.get(tabId)
      if (tab.status === 'complete' && tab.url?.startsWith('https://web.whatsapp.com/')) {
        const result = await chrome.tabs.sendMessage(tabId, command)
        if (result) return result
      }
    } catch (error) {
      lastError = error.message || String(error)
    }
    await new Promise((resolve) => setTimeout(resolve, 700))
  }
  throw new Error(lastError || 'O WhatsApp Web demorou demais para ficar pronto.')
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!sender.tab?.url?.startsWith(allowedSite)) {
    sendResponse({ ok: false, error: 'Origem não autorizada.' })
    return false
  }
  if (message.type === 'PING') {
    sendResponse({
      ok: true,
      result: {
        installed: true,
        version: chrome.runtime.getManifest().version,
      },
    })
    return false
  }
  if (!['SEND_WHATSAPP', 'SEND_INSTAGRAM'].includes(message.type)) return false

  ;(async () => {
    if (message.type === 'SEND_INSTAGRAM') {
      const profileUrl = String(message.payload?.profileUrl || '')
      const text = String(message.payload?.message || '').trim()
      if (!profileUrl.startsWith('https://www.instagram.com/') || !text) {
        throw new Error('Perfil ou mensagem do Instagram inválidos.')
      }
      const existing = await chrome.tabs.query({ url: 'https://www.instagram.com/*' })
      const existingIds = existing.map((item) => item.id).filter(Number.isInteger)
      if (existingIds.length) await chrome.tabs.remove(existingIds)
      const tab = await chrome.tabs.create({ url: profileUrl, active: true })
      try {
        const result = await deliverToInstagram(tab.id, { type: 'FLYFLOW_SEND_INSTAGRAM', text })
        if (!result?.ok) throw new Error(result?.error || 'O Instagram não confirmou o envio.')
        return result
      } finally {
        await chrome.tabs.remove(tab.id).catch(() => undefined)
      }
    }

    const phone = String(message.payload?.phone || '').replace(/\D/g, '')
    const normalizedPhone = phone.startsWith('55') ? phone : `55${phone}`
    const text = String(message.payload?.message || '').trim()
    if (normalizedPhone.length < 12 || !text) throw new Error('Número ou mensagem inválidos.')
    const url = `https://web.whatsapp.com/send?phone=${normalizedPhone}&text=${encodeURIComponent(text)}`
    const existing = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' })
    const existingIds = existing.map((item) => item.id).filter(Number.isInteger)
    if (existingIds.length) await chrome.tabs.remove(existingIds)
    const tab = await chrome.tabs.create({ url, active: true })
    try {
      const result = await deliverToWhatsApp(tab.id, {
        type: 'FLYFLOW_SEND',
        phone: normalizedPhone,
        text,
      })
      if (!result?.ok) throw new Error(result?.error || 'O WhatsApp Web não confirmou o envio.')
      return result
    } finally {
      await chrome.tabs.remove(tab.id).catch(() => undefined)
    }
  })().then(
    (result) => sendResponse({ ok: true, result }),
    (error) => sendResponse({ ok: false, error: error.message }),
  )
  return true
})

async function deliverToInstagram(tabId, command) {
  const startedAt = Date.now()
  let lastError = ''
  while (Date.now() - startedAt < 55_000) {
    try {
      const tab = await chrome.tabs.get(tabId)
      if (tab.status === 'complete' && tab.url?.startsWith('https://www.instagram.com/')) {
        const result = await chrome.tabs.sendMessage(tabId, command)
        if (result) return result
      }
    } catch (error) {
      lastError = error.message || String(error)
    }
    await new Promise((resolve) => setTimeout(resolve, 700))
  }
  throw new Error(lastError || 'O Instagram demorou demais para ficar pronto.')
}
